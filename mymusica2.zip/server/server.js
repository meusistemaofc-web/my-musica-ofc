// My Music — servidor completo (frontend + API) sem dependências externas.
// Requer Node.js 22.13 ou superior (usa o SQLite embutido do Node).
import http from "node:http";
import fs from "node:fs";
import path from "node:path";
import { config } from "./config.js";
import { Router, HttpError, readJson, readRaw, sendJson } from "./http.js";
import { loadSession } from "./auth.js";
import { registerCore } from "./routes/core.js";
import { registerAdmin } from "./routes/admin.js";
import { registerExtras } from "./routes/extras.js";
import { registerPayments, startPaymentWatcher } from "./routes/payments.js";
import { registerAdvertising } from "./routes/advertising.js";
import { registerRadio } from "./routes/radio.js";
import { handleGeneric } from "./routes/generic.js";
import { db, docs } from "./db.js";
import { dirs } from "./util.js";

const router = new Router();
registerCore(router);
registerAdmin(router);
registerPayments(router);
registerAdvertising(router);
registerRadio(router);
registerExtras(router);
startPaymentWatcher();

const HANDLED = Symbol("handled");
const VERSION = JSON.parse(fs.readFileSync(path.join(config.root, "package.json"), "utf8")).version;

const MIME = {
  ".html": "text/html; charset=utf-8", ".js": "text/javascript; charset=utf-8", ".css": "text/css; charset=utf-8",
  ".json": "application/json; charset=utf-8", ".svg": "image/svg+xml", ".png": "image/png", ".jpg": "image/jpeg",
  ".jpeg": "image/jpeg", ".webp": "image/webp", ".ico": "image/x-icon", ".txt": "text/plain; charset=utf-8",
  ".webmanifest": "application/manifest+json", ".woff2": "font/woff2", ".mp3": "audio/mpeg", ".map": "application/json",
};

const indexHtml = () => fs.readFileSync(path.join(config.publicDir, "index.html"));

function serveStatic(req, res, pathname) {
  let rel = decodeURIComponent(pathname);
  if (rel.includes("\0")) return false;
  const file = path.normalize(path.join(config.publicDir, rel));
  if (!file.startsWith(config.publicDir)) return false;
  let stat;
  try { stat = fs.statSync(file); } catch { return false; }
  if (!stat.isFile()) return false;
  const ext = path.extname(file).toLowerCase();
  const headers = { "Content-Type": MIME[ext] || "application/octet-stream", "Content-Length": stat.size };
  if (rel.startsWith("/assets/")) headers["Cache-Control"] = "public, max-age=31536000, immutable";
  else if (rel === "/sw.js") { headers["Cache-Control"] = "no-cache"; headers["Service-Worker-Allowed"] = "/"; }
  else headers["Cache-Control"] = "public, max-age=3600";
  res.writeHead(200, headers);
  if (req.method === "HEAD") return res.end(), true;
  fs.createReadStream(file).pipe(res);
  return true;
}

const server = http.createServer(async (req, res) => {
  const url = new URL(req.url, "http://localhost");
  const pathname = url.pathname;
  res.setHeader("X-Content-Type-Options", "nosniff");
  res.setHeader("Referrer-Policy", "strict-origin-when-cross-origin");
  res.setHeader("X-Frame-Options", "SAMEORIGIN");
  res.setHeader("Permissions-Policy", "microphone=(self), camera=(), geolocation=(self)");

  if (!pathname.startsWith("/api/")) {
    if ((req.method === "GET" || req.method === "HEAD") && serveStatic(req, res, pathname)) return;
    if (req.method !== "GET" && req.method !== "HEAD") { res.writeHead(405); return res.end(); }
    if (pathname.startsWith("/assets/")) { res.writeHead(404, { "Content-Type": "text/plain" }); return res.end("Not found"); }
    // SPA: qualquer rota do app devolve o index.html
    const html = indexHtml();
    res.writeHead(200, { "Content-Type": "text/html; charset=utf-8", "Cache-Control": "no-cache", "Content-Length": html.length });
    return res.end(req.method === "HEAD" ? undefined : html);
  }

  if (pathname === "/api/health") return sendJson(res, 200, { ok: true, version: VERSION, time: new Date().toISOString() });
  if (pathname === "/api/__routes" && process.env.MM_TEST === "1") return sendJson(res, 200, router.routes.map((r) => ({ method: r.method, pattern: r.pattern })));

  const { user, session } = loadSession(req);
  let bodyCache;
  const ctx = {
    req, res, url, query: url.searchParams, user, session, params: {}, HANDLED,
    json: async () => (bodyCache ??= await readJson(req)),
    raw: (limit) => readRaw(req, limit),
  };
  try {
    const match = router.match(req.method, pathname);
    let result;
    if (match && match.handler) {
      ctx.params = match.params;
      result = await match.handler(ctx);
    } else {
      result = await handleGeneric(ctx, req.method, pathname);
    }
    if (result === HANDLED || res.headersSent) return;
    sendJson(res, 200, result);
  } catch (err) {
    if (res.headersSent) { res.end(); return; }
    if (err instanceof HttpError) return sendJson(res, err.status, { error: err.message });
    console.error(`[erro] ${req.method} ${pathname}:`, err);
    sendJson(res, 500, { error: "Erro interno do servidor." });
  }
});

server.requestTimeout = 0; // envios grandes e streaming não podem cair por tempo
server.headersTimeout = 65_000;
server.listen(config.port, config.host, () => {
  console.log(`🎧 My Music rodando em http://${config.host === "0.0.0.0" ? "localhost" : config.host}:${config.port}`);
  console.log(`   Dados em: ${config.dataDir}`);
});

// Limpeza diária: sessões antigas, links de senha vencidos e envios de música abandonados.
function maintenance() {
  try {
    db.prepare("DELETE FROM sessions WHERE last_seen < ?").run(new Date(Date.now() - 400 * 86400e3).toISOString());
    for (const r of docs.list("resets")) if (new Date(r.expiresAt) < new Date()) docs.del("resets", r.id);
    for (const s of docs.list("songs")) {
      if (s.status === "uploading" && Date.now() - new Date(s.createdAt).getTime() > 3 * 86400e3) {
        fs.rmSync(path.join(dirs.uploads, s.id), { recursive: true, force: true });
        fs.rmSync(path.join(dirs.audio, s.id), { force: true });
        docs.del("songs", s.id);
      }
    }
  } catch (e) { console.error("[manutenção]", e.message); }
}
setTimeout(maintenance, 60_000).unref();
setInterval(maintenance, 24 * 3600e3).unref();

process.on("unhandledRejection", (e) => console.error("[erro não tratado]", e));
for (const sig of ["SIGINT", "SIGTERM"]) process.on(sig, () => { server.close(); db.close(); process.exit(0); });
