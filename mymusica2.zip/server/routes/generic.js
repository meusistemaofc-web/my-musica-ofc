// Endpoints que o app chama mas que não foram reconstruídos nesta instalação.
// Em vez de quebrar a tela, devolvemos um erro amigável que o app mostra como aviso.
import { HttpError } from "../http.js";

// Chamadas de telemetria/registro: podem simplesmente ser aceitas.
const ACCEPT = [
  /^\/api\/referral\/click$/, /^\/api\/radio\/presence$/, /^\/api\/onboarding\/device$/, /^\/api\/push\/opened$/,
  /^\/api\/advertising\/live\/[^/]+\/(view|click)$/, /^\/api\/audio-ads\/[^/]+\/played$/, /^\/api\/notices\/referral\/popup$/,
  /^\/api\/received\/seen$/, /^\/api\/referral\/rewards\/seen$/, /^\/api\/admin\/alerts\/read$/,
];

export async function handleGeneric(ctx, method, pathname) {
  if (method !== "GET" && ACCEPT.some((re) => re.test(pathname))) {
    if (!ctx.user && !/referral\/click/.test(pathname)) throw new HttpError(401, "Faça login para continuar.");
    return { ok: true };
  }
  if (!ctx.user) throw new HttpError(401, "Faça login para continuar.");
  throw new HttpError(501, "Este recurso ainda não está disponível nesta instalação do My Music.");
}
