import fs from "node:fs";
import path from "node:path";
import { spawn } from "node:child_process";
import { users, sessions, docs, kvGet, kvSet, now } from "../db.js";
import { config } from "../config.js";
import { fail } from "../http.js";
import { hashPassword, verifyPassword, publicUser, startSession, endSession, requireUser, requireAdmin } from "../auth.js";
import { uuid, randKey, slug, dirs, coverUrl, saveCover, songOut, songStats, setSongStats, audioPath, userAgentDevice } from "../util.js";
import { sendEmail } from "../email.js";

// Limite de tentativas por IP (protege login, cadastro e recuperação de senha contra abuso)
const attempts = new Map();
function limit(ctx, bucket, max = 10, windowMs = 10 * 60e3) {
  if (process.env.RATE_LIMIT === "off") return;
  const ip = ctx.req.headers["x-forwarded-for"]?.split(",")[0].trim() || ctx.req.socket.remoteAddress || "?";
  const key = `${bucket}:${ip}`;
  const t = Date.now();
  const list = (attempts.get(key) || []).filter((x) => t - x < windowMs);
  if (list.length >= max) fail(429, "Muitas tentativas. Aguarde alguns minutos e tente de novo.");
  list.push(t);
  attempts.set(key, list);
  if (attempts.size > 5000) attempts.clear();
}
const clearLimit = (ctx, bucket) => {
  const ip = ctx.req.headers["x-forwarded-for"]?.split(",")[0].trim() || ctx.req.socket.remoteAddress || "?";
  attempts.delete(`${bucket}:${ip}`);
};

const SONGS = "songs";
const PL = "playlists";
const CAT = "categories";

// ===================================================================================
// Autenticação
// ===================================================================================
function accessSettings() {
  return { requireApproval: false, signupEnabled: true, singleDevice: false, ...kvGet("setting:/api/admin/access", {}) };
}

function sessionPayload(ctx) {
  const setupRequired = users.count() === 0;
  return { user: publicUser(ctx.user), setupRequired, singleDevice: !!accessSettings().singleDevice, ended: null };
}

function validEmail(e) { return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(String(e || "").trim()); }

export function registerCore(r) {
  r.get("/api/auth/session", (ctx) => sessionPayload(ctx));

  r.post("/api/auth/setup", async (ctx) => {
    if (users.count() > 0) fail(409, "O administrador já foi configurado. Faça login.");
    const b = await ctx.json();
    if (!b.password || String(b.password).length < 8) fail(400, "A senha deve ter pelo menos 8 caracteres.");
    const email = validEmail(b.email) ? b.email.trim() : config.adminEmail;
    const user = users.create({ email, passwordHash: hashPassword(b.password), role: "admin",
      data: { displayName: (b.displayName || "Administrador").trim(), access: "approved" } });
    startSession(ctx.req, ctx.res, user);
    return { user: publicUser(user), singleDevice: false };
  });

  r.post("/api/auth/signup", async (ctx) => {
    limit(ctx, "signup", 8, 60 * 60e3);
    const b = await ctx.json();
    const s = accessSettings();
    if (s.signupEnabled === false) fail(403, "Novos cadastros estão desativados no momento.");
    if (!validEmail(b.email)) fail(400, "Informe um e-mail válido.");
    if (!b.password || String(b.password).length < 8) fail(400, "A senha deve ter pelo menos 8 caracteres.");
    if (b.confirm !== undefined && b.confirm !== b.password) fail(400, "As senhas não coincidem.");
    if (users.byEmail(b.email)) fail(409, "Já existe uma conta com este e-mail.");
    const user = users.create({ email: b.email.trim(), passwordHash: hashPassword(b.password), role: "user",
      data: { displayName: (b.displayName || "").trim(), access: s.requireApproval ? "pending" : "approved",
        referral: b.referral?.code || null } });
    startSession(ctx.req, ctx.res, user);
    return { user: publicUser(user), singleDevice: !!s.singleDevice };
  });

  r.post("/api/auth/login", async (ctx) => {
    limit(ctx, "login");
    const b = await ctx.json();
    const user = users.byEmail(String(b.email || "").trim());
    if (!user || !verifyPassword(b.password, users.hash(user.id))) fail(401, "E-mail ou senha incorretos.");
    if (user.blocked) fail(403, "Esta conta está bloqueada. Fale com o administrador.");
    const s = accessSettings();
    if (s.singleDevice && user.role !== "admin") sessions.removeUser(user.id);
    clearLimit(ctx, "login");
    startSession(ctx.req, ctx.res, user);
    users.updateData(user.id, { lastLoginAt: now() });
    return { user: publicUser(users.byId(user.id)), singleDevice: !!s.singleDevice };
  });

  r.post("/api/auth/logout", (ctx) => { endSession(ctx.req, ctx.res); return { ok: true }; });

  r.post("/api/auth/password", async (ctx) => {
    const u = requireUser(ctx);
    const b = await ctx.json();
    const current = b.current ?? b.currentPassword ?? b.oldPassword;
    const next = b.password ?? b.newPassword ?? b.next;
    if (!verifyPassword(current, users.hash(u.id))) fail(400, "A senha atual está incorreta.");
    if (!next || String(next).length < 8) fail(400, "A nova senha deve ter pelo menos 8 caracteres.");
    users.setPassword(u.id, hashPassword(next));
    return { ok: true };
  });

  r.post("/api/auth/forgot", async (ctx) => {
    limit(ctx, "forgot", 5, 30 * 60e3);
    const b = await ctx.json();
    const user = users.byEmail(String(b.email || "").trim());
    if (user) {
      const token = randKey(24);
      docs.put("resets", token, { userId: user.id, expiresAt: new Date(Date.now() + 3600e3).toISOString() });
      const base = config.publicUrl || `${ctx.req.headers["x-forwarded-proto"] || "http"}://${ctx.req.headers.host}`;
      const link = `${base}/redefinir-senha?token=${token}`;
      const sent = await sendEmail({
        to: user.email, subject: "Redefinir sua senha do My Music",
        text: `Olá! Para criar uma nova senha, abra este link (vale por 1 hora):\n${link}\n\nSe você não pediu, ignore este e-mail.`,
        html: `<p>Olá!</p><p>Para criar uma nova senha do <b>My Music</b>, toque no botão abaixo (vale por 1 hora):</p><p><a href="${link}" style="background:#2f7dff;color:#fff;padding:12px 20px;border-radius:10px;text-decoration:none;display:inline-block">Criar nova senha</a></p><p style="color:#888">Se você não pediu, ignore este e-mail.</p>`,
      });
      if (!sent) console.log(`[senha] E-mail não configurado. Link de redefinição para ${user.email}: ${link}`);
    }
    return { ok: true };
  });

  r.post("/api/auth/reset", async (ctx) => {
    limit(ctx, "reset", 10);
    const b = await ctx.json();
    const rec = docs.get("resets", b.token || "");
    if (!rec || new Date(rec.expiresAt) < new Date()) fail(400, "Este link expirou ou já foi usado. Peça um novo.");
    if (!b.password || String(b.password).length < 8) fail(400, "A senha deve ter pelo menos 8 caracteres.");
    users.setPassword(rec.userId, hashPassword(b.password));
    docs.del("resets", b.token);
    const user = users.byId(rec.userId);
    startSession(ctx.req, ctx.res, user);
    return { user: publicUser(user), singleDevice: !!accessSettings().singleDevice };
  });

  r.post("/api/auth/approval-seen", (ctx) => { const u = requireUser(ctx); users.updateData(u.id, { approvedNotice: false }); return { ok: true }; });

  // ===================================================================================
  // Perfil
  // ===================================================================================
  const profile = (u) => ({ ...publicUser(u), settings: { recordHistory: true, autoplayNext: true, ...(u.settings || {}) },
    covers: { auto: false, allowReplace: true, ...(u._data.covers || {}) } });
  r.get("/api/me", (ctx) => profile(requireUser(ctx)));
  r.patch("/api/me", async (ctx) => {
    const u = requireUser(ctx);
    const b = await ctx.json();
    const partial = {};
    if (typeof b.displayName === "string") partial.displayName = b.displayName.trim();
    if (typeof b.name === "string") partial.displayName = b.name.trim();
    if (b.settings && typeof b.settings === "object") partial.settings = { ...(u.settings || {}), ...b.settings };
    if (b.avatarUrl !== undefined) partial.avatarUrl = b.avatarUrl;
    if (b.covers && typeof b.covers === "object") partial.covers = { ...(u._data.covers || {}), ...b.covers };
    if (typeof b.email === "string" && validEmail(b.email) && b.email.toLowerCase() !== u.email) {
      if (users.byEmail(b.email)) fail(409, "Este e-mail já está em uso.");
      users.setEmail(u.id, b.email);
    }
    return profile(users.updateData(u.id, partial));
  });

  // ===================================================================================
  // Capas
  // ===================================================================================
  r.post("/api/covers", async (ctx) => {
    requireUser(ctx);
    const type = String(ctx.req.headers["content-type"] || "");
    if (type.includes("application/json")) {
      const b = await ctx.json();
      if (!b.url) fail(400, "Informe a URL da imagem.");
      let resp;
      try { resp = await fetch(b.url, { signal: AbortSignal.timeout(15000) }); } catch { fail(502, "Não foi possível baixar a imagem."); }
      if (!resp.ok) fail(502, "Não foi possível baixar a imagem.");
      const buf = Buffer.from(await resp.arrayBuffer());
      if (buf.length > 15 * 1024 * 1024) fail(413, "Imagem grande demais.");
      return { key: saveCover(buf, resp.headers.get("content-type") || "image/jpeg") };
    }
    const buf = await ctx.raw(15 * 1024 * 1024);
    if (!buf.length) fail(400, "Imagem vazia.");
    return { key: saveCover(buf, type || "image/jpeg") };
  });

  r.get("/api/covers/:key", (ctx) => {
    const key = ctx.params.key.replace(/[^a-zA-Z0-9_-]/g, "");
    const file = path.join(dirs.covers, key);
    if (!key || !fs.existsSync(file)) fail(404, "Capa não encontrada.");
    let type = "image/jpeg";
    try { type = fs.readFileSync(file + ".type", "utf8"); } catch {}
    ctx.res.writeHead(200, { "Content-Type": type, "Cache-Control": "public, max-age=31536000, immutable" });
    fs.createReadStream(file).pipe(ctx.res);
    return ctx.HANDLED;
  });

  r.patch("/api/covers/:key", async (ctx) => { requireAdmin(ctx); return { key: ctx.params.key, ok: true }; });

  r.get("/api/files/:key", (ctx) => {
    const key = ctx.params.key.replace(/[^a-zA-Z0-9]/g, "");
    const file = path.join(dirs.files, key);
    if (!fs.existsSync(file)) fail(404, "Arquivo não encontrado.");
    let meta = {};
    try { meta = JSON.parse(fs.readFileSync(file + ".json", "utf8")); } catch {}
    return streamFile(ctx, file, meta.contentType || "application/octet-stream");
  });

  // ===================================================================================
  // Músicas
  // ===================================================================================
  const visibleSongs = (ctx, status) => {
    const all = docs.list(SONGS);
    if (status) return all.filter((s) => s.status === status);
    return all.filter((s) => s.status === "ready");
  };

  r.get("/api/songs", (ctx) => {
    const u = requireUser(ctx);
    const status = ctx.query.get("status");
    if (status && u.role !== "admin") return [];
    return visibleSongs(ctx, status).map((s) => songOut(s, u.id));
  });

  r.post("/api/songs/check", async (ctx) => {
    requireAdmin(ctx);
    const b = await ctx.json();
    const dup = b.contentHash && docs.list(SONGS).find((s) => s.contentHash === b.contentHash && s.status === "ready");
    if (dup) fail(409, `Esta música já está na biblioteca: “${dup.title}”.`);
    return { ok: true, duplicate: false };
  });

  r.post("/api/songs", async (ctx) => {
    const u = requireAdmin(ctx);
    const b = await ctx.json();
    const size = Number(b.size) || 0;
    if (size <= 0) fail(400, "O arquivo está vazio.");
    if (size > config.maxUploadBytes) fail(413, "O arquivo excede o tamanho máximo de 200 MB.");
    const id = uuid();
    const song = docs.put(SONGS, id, {
      title: b.title || "Sem título", artist: b.artist || "", album: b.album || "", duration: Number(b.duration) || 0,
      mimeType: b.mimeType || "audio/mpeg", size, coverKey: b.coverKey || null, contentHash: b.contentHash || null,
      status: "uploading", audioVersion: 0, categoryIds: [], ownerId: u.id, uploadId: b.uploadId || null, createdAt: now(),
    });
    fs.mkdirSync(path.join(dirs.uploads, id), { recursive: true });
    return songOut(song, u.id);
  });

  const storedChunks = (id) => {
    const dir = path.join(dirs.uploads, id);
    if (!fs.existsSync(dir)) return [];
    return fs.readdirSync(dir).filter((f) => /^\d+$/.test(f)).map(Number).sort((a, b) => a - b);
  };

  r.put("/api/songs/:id/chunks/:n", async (ctx) => {
    requireAdmin(ctx);
    const song = docs.get(SONGS, ctx.params.id);
    if (!song) fail(404, "Envio não encontrado.");
    const n = Number(ctx.params.n);
    if (!Number.isInteger(n) || n < 0) fail(400, "Parte inválida.");
    const buf = await ctx.raw(config.chunkSize + 1024);
    fs.mkdirSync(path.join(dirs.uploads, song.id), { recursive: true });
    fs.writeFileSync(path.join(dirs.uploads, song.id, String(n)), buf);
    return { ok: true, index: n, size: buf.length };
  });

  r.get("/api/songs/:id/upload", (ctx) => {
    const u = requireAdmin(ctx);
    let song = docs.get(SONGS, ctx.params.id);
    if (!song) song = docs.list(SONGS).find((s) => s.uploadId === ctx.params.id);
    if (!song) return { state: "missing", song: null, stored: [] };
    if (song.status === "converting") return { state: "converting", song: songOut(song, u.id), conversion: docs.get("conversions", song.conversionId) };
    if (song.status === "uploading") return { state: "pending", song: songOut(song, u.id), stored: storedChunks(song.id) };
    return { state: "done", song: songOut(song, u.id) };
  });

  r.post("/api/songs/:id/complete", async (ctx) => {
    const u = requireAdmin(ctx);
    const b = await ctx.json();
    const song = docs.get(SONGS, ctx.params.id);
    if (!song) fail(404, "Envio não encontrado.");
    if (song.status !== "uploading") return songOut(song, u.id);
    const expected = Math.max(1, Math.ceil(song.size / config.chunkSize));
    const have = storedChunks(song.id);
    if (have.length < expected) fail(400, `Envio incompleto (${have.length} de ${expected} partes). Tente novamente.`);
    const dest = audioPath(song.id);
    const fd = fs.openSync(dest, "w");
    for (let i = 0; i < expected; i++) fs.writeSync(fd, fs.readFileSync(path.join(dirs.uploads, song.id, String(i))));
    fs.closeSync(fd);
    fs.rmSync(path.join(dirs.uploads, song.id), { recursive: true, force: true });
    const size = fs.statSync(dest).size;
    const publish = b.publish !== false;
    const isVideo = /^video\//.test(song.mimeType) || b.convert === true;
    if (isVideo) {
      const conv = startConversion(song.id, publish, b.playlistId);
      const updated = docs.patch(SONGS, song.id, { size, status: "converting", conversionId: conv.id });
      return { ...songOut(updated, u.id), conversion: conv };
    }
    const updated = docs.patch(SONGS, song.id, { size, status: publish ? "ready" : "draft" });
    if (b.playlistId) addSongToPlaylist(b.playlistId, song.id);
    return songOut(updated, u.id);
  });

  r.get("/api/conversions/:id", (ctx) => {
    const u = requireUser(ctx);
    const c = docs.get("conversions", ctx.params.id);
    if (!c) fail(404, "Conversão não encontrada.");
    return { ...c, song: c.status === "done" ? songOut(docs.get(SONGS, c.songId), u.id) : null };
  });

  r.post("/api/songs/:id/convert", async (ctx) => {
    const u = requireAdmin(ctx);
    const song = docs.get(SONGS, ctx.params.id);
    if (!song) fail(404, "Música não encontrada.");
    const conv = startConversion(song.id, song.status === "ready", null);
    docs.patch(SONGS, song.id, { status: "converting", conversionId: conv.id });
    return { ...songOut(docs.get(SONGS, song.id), u.id), conversion: conv };
  });

  r.post("/api/songs/:id/publish", (ctx) => {
    const u = requireAdmin(ctx);
    const s = docs.patch(SONGS, ctx.params.id, { status: "ready" });
    if (!s) fail(404, "Música não encontrada.");
    return songOut(s, u.id);
  });

  r.patch("/api/songs/:id", async (ctx) => {
    const u = requireUser(ctx);
    const b = await ctx.json();
    const song = docs.get(SONGS, ctx.params.id);
    if (!song) fail(404, "Música não encontrada.");
    if (b.favorite !== undefined) setSongStats(u.id, song.id, { favorite: !!b.favorite });
    const editable = ["title", "artist", "album", "genre", "year", "duration", "coverKey"];
    const partial = {};
    for (const k of editable) if (b[k] !== undefined) partial[k] = b[k];
    if (Object.keys(partial).length) {
      if (u.role !== "admin") fail(403, "Apenas o administrador pode editar músicas.");
      docs.patch(SONGS, song.id, partial);
    }
    return songOut(docs.get(SONGS, song.id), u.id);
  });

  r.delete("/api/songs/:id", (ctx) => {
    requireAdmin(ctx);
    const id = ctx.params.id;
    docs.del(SONGS, id);
    fs.rmSync(audioPath(id), { force: true });
    fs.rmSync(path.join(dirs.uploads, id), { recursive: true, force: true });
    for (const p of docs.list(PL)) if ((p.songIds || []).includes(id)) docs.patch(PL, p.id, { songIds: p.songIds.filter((x) => x !== id) });
    for (const p of docs.list("user-playlists")) if ((p.songIds || []).includes(id)) docs.patch("user-playlists", p.id, { songIds: p.songIds.filter((x) => x !== id) });
    return { ok: true };
  });

  r.delete("/api/songs", async (ctx) => {
    requireAdmin(ctx);
    const b = await ctx.json();
    for (const id of b.ids || []) { docs.del(SONGS, id); fs.rmSync(audioPath(id), { force: true }); }
    return { ok: true, deleted: (b.ids || []).length };
  });

  r.put("/api/songs/:id/categories", async (ctx) => {
    const u = requireAdmin(ctx);
    const b = await ctx.json();
    const ids = b.categoryIds || b.ids || [];
    const s = docs.patch(SONGS, ctx.params.id, { categoryIds: ids });
    if (!s) fail(404, "Música não encontrada.");
    return { ...songOut(s, u.id), songId: s.id, categoryIds: ids };
  });

  r.post("/api/songs/:id/cover", async (ctx) => {
    const u = requireAdmin(ctx);
    const b = await ctx.json();
    const song = docs.get(SONGS, ctx.params.id);
    if (!song) fail(404, "Música não encontrada.");
    let key = b.coverKey || b.key || null;
    if (!key && (b.url || b.imageUrl)) {
      try {
        const resp = await fetch(b.url || b.imageUrl, { signal: AbortSignal.timeout(15000) });
        if (resp.ok) key = saveCover(Buffer.from(await resp.arrayBuffer()), resp.headers.get("content-type") || "image/jpeg");
      } catch {}
    }
    if (!key) fail(400, "Não foi possível obter a imagem.");
    const targets = b.applyToAlbum && song.album
      ? docs.list(SONGS).filter((s) => s.album === song.album && s.artist === song.artist)
      : [song];
    return { songs: targets.map((s) => songOut(docs.patch(SONGS, s.id, { coverKey: key }), u.id)) };
  });

  r.get("/api/songs/:id/stream", (ctx) => {
    requireUser(ctx);
    const song = docs.get(SONGS, ctx.params.id);
    if (!song || !fs.existsSync(audioPath(song.id))) fail(404, "Arquivo de áudio não encontrado.");
    return streamFile(ctx, audioPath(song.id), song.mimeType || "audio/mpeg");
  });

  r.get("/api/songs/:id/download", (ctx) => {
    requireUser(ctx);
    const song = docs.get(SONGS, ctx.params.id);
    if (!song || !fs.existsSync(audioPath(song.id))) fail(404, "Arquivo de áudio não encontrado.");
    const ext = song.mimeType === "audio/mpeg" ? "mp3" : (song.mimeType || "").split("/")[1] || "bin";
    const name = `${song.artist ? song.artist + " - " : ""}${song.title}.${ext}`.replace(/[\\/:*?"<>|]/g, "_");
    ctx.res.setHeader("Content-Disposition", `attachment; filename*=UTF-8''${encodeURIComponent(name)}`);
    return streamFile(ctx, audioPath(song.id), song.mimeType || "audio/mpeg");
  });

  r.get("/api/public/songs/:id", (ctx) => {
    const song = docs.get(SONGS, ctx.params.id);
    if (!song || song.status !== "ready") fail(404, "Música não encontrada.");
    const o = songOut(song, ctx.user?.id);
    return { song: o, ...o };
  });

  // Download para ouvir offline (em partes)
  r.post("/api/offline/songs/:id", (ctx) => {
    const u = requireUser(ctx);
    const song = docs.get(SONGS, ctx.params.id);
    if (!song) fail(404, "Música não encontrada.");
    const o = songOut(song, u.id);
    return { song: o, chunkCount: o.chunkCount, chunkSize: o.chunkSize, license: offlineLicense(u) };
  });
  r.get("/api/offline/songs/:id/chunks/:n", (ctx) => {
    requireUser(ctx);
    const song = docs.get(SONGS, ctx.params.id);
    if (!song || !fs.existsSync(audioPath(song.id))) fail(404, "Arquivo não encontrado.");
    const n = Number(ctx.params.n);
    const start = n * config.chunkSize;
    const end = Math.min(song.size, start + config.chunkSize) - 1;
    if (start >= song.size) fail(416, "Parte inválida.");
    ctx.res.writeHead(200, { "Content-Type": "application/octet-stream", "Content-Length": end - start + 1, "Cache-Control": "no-store" });
    fs.createReadStream(audioPath(song.id), { start, end }).pipe(ctx.res);
    return ctx.HANDLED;
  });
  r.delete("/api/offline/songs/:id", (ctx) => { requireUser(ctx); return { ok: true }; });
  r.get("/api/offline/license", (ctx) => offlineLicense(requireUser(ctx)));

  // ===================================================================================
  // Histórico de reprodução
  // ===================================================================================
  r.post("/api/plays", async (ctx) => {
    const u = requireUser(ctx);
    const b = await ctx.json();
    const song = docs.get(SONGS, b.songId);
    if (!song) return { ok: true };
    const playedAt = b.playedAt || now();
    const st = songStats(u.id, song.id);
    setSongStats(u.id, song.id, { playCount: (st.playCount || 0) + 1, lastPlayedAt: playedAt });
    if (u.settings?.recordHistory !== false) docs.put("plays", uuid(), { userId: u.id, songId: song.id, playedAt, createdAt: playedAt }, u.id);
    return { ok: true };
  });
  r.get("/api/plays", (ctx) => {
    const u = requireUser(ctx);
    const limit = Math.min(1000, Number(ctx.query.get("limit")) || 200);
    return docs.list("plays", u.id)
      .sort((a, b) => b.playedAt.localeCompare(a.playedAt))
      .slice(0, limit)
      .map((p) => ({ id: p.id, playedAt: p.playedAt, song: songOut(docs.get(SONGS, p.songId), u.id) }))
      .filter((p) => p.song);
  });
  r.delete("/api/plays", (ctx) => {
    const u = requireUser(ctx);
    docs.delWhere("plays", (p) => p.userId === u.id);
    return { ok: true };
  });

  // ===================================================================================
  // Categorias
  // ===================================================================================
  const catOut = (c) => ({ active: true, order: 0, description: "", ...c, coverUrl: coverUrl(c.coverKey),
    songCount: docs.list(SONGS).filter((s) => s.status === "ready" && (s.categoryIds || []).includes(c.id)).length });
  const allCats = () => docs.list(CAT).sort((a, b) => (a.order ?? 0) - (b.order ?? 0)).map(catOut);
  r.get("/api/categories", (ctx) => {
    requireUser(ctx);
    const songs = {};
    for (const s of docs.list(SONGS)) if ((s.categoryIds || []).length) songs[s.id] = s.categoryIds;
    return { categories: allCats(), songs };
  });
  r.get("/api/categories/:id", (ctx) => {
    const u = requireUser(ctx);
    const c = docs.get(CAT, ctx.params.id);
    if (!c) fail(404, "Categoria não encontrada.");
    const songs = docs.list(SONGS).filter((s) => s.status === "ready" && (s.categoryIds || []).includes(c.id)).map((s) => songOut(s, u.id));
    return { ...catOut(c), category: catOut(c), songs };
  });
  r.post("/api/categories", async (ctx) => {
    requireAdmin(ctx);
    const b = await ctx.json();
    if (!String(b.name || "").trim()) fail(400, "Informe o nome da categoria.");
    const order = docs.list(CAT).length;
    return catOut(docs.put(CAT, uuid(), { active: true, order, ...b, name: b.name.trim(), createdAt: now() }));
  });
  r.patch("/api/categories/:id", async (ctx) => {
    requireAdmin(ctx);
    const c = docs.patch(CAT, ctx.params.id, await ctx.json());
    if (!c) fail(404, "Categoria não encontrada.");
    return catOut(c);
  });
  r.delete("/api/categories/:id", (ctx) => {
    requireAdmin(ctx);
    const id = ctx.params.id;
    docs.del(CAT, id);
    for (const s of docs.list(SONGS)) if ((s.categoryIds || []).includes(id)) docs.patch(SONGS, s.id, { categoryIds: s.categoryIds.filter((x) => x !== id) });
    return { ok: true };
  });
  r.put("/api/categories/order", async (ctx) => {
    requireAdmin(ctx);
    const b = await ctx.json();
    (b.ids || b.order || []).forEach((id, i) => docs.patch(CAT, id, { order: i }));
    return { categories: allCats() };
  });
  r.post("/api/categories/defaults", (ctx) => {
    requireAdmin(ctx);
    const names = ["Sertanejo", "Pop", "Rock", "Gospel", "Forró", "Pagode", "Funk", "MPB", "Eletrônica", "Rap / Hip-hop", "Românticas", "Internacionais"];
    const existing = new Set(docs.list(CAT).map((c) => c.name.toLowerCase()));
    let order = docs.list(CAT).length;
    for (const name of names) if (!existing.has(name.toLowerCase())) docs.put(CAT, uuid(), { name, active: true, order: order++, createdAt: now() });
    return { categories: allCats() };
  });

  // ===================================================================================
  // Playlists (da biblioteca, criadas pelo administrador)
  // ===================================================================================
  r.get("/api/playlists", (ctx) => {
    const u = requireUser(ctx);
    return docs.list(PL).filter((p) => u.role === "admin" || !p.hidden).map((p) => playlistOut(p, u));
  });
  r.get("/api/playlists/assignments", (ctx) => {
    requireUser(ctx);
    const out = {};
    for (const p of docs.list(PL)) for (const sid of p.songIds || []) (out[sid] ||= []).push(p.id);
    return out;
  });
  r.get("/api/playlists/:id", (ctx) => {
    const u = requireUser(ctx);
    const p = docs.get(PL, ctx.params.id) || docs.list(PL).find((x) => x.slug === ctx.params.id);
    if (!p || (p.hidden && u.role !== "admin")) fail(404, "Esta playlist não existe mais.");
    return playlistOut(p, u, true);
  });
  r.post("/api/playlists", async (ctx) => {
    const u = requireAdmin(ctx);
    const b = await ctx.json();
    if (!String(b.name || "").trim()) fail(400, "Informe o nome da playlist.");
    const p = docs.put(PL, uuid(), { name: b.name.trim(), coverKey: b.coverKey || null, isPublic: b.isPublic !== false,
      exclusive: !!b.exclusive, categoryId: b.categoryId || null, hidden: false, hiddenAt: null, songIds: [], slug: slug(10),
      ownerId: u.id, createdAt: now() });
    return playlistOut(p, u);
  });
  const updatePlaylist = async (ctx) => {
    const u = requireAdmin(ctx);
    const b = await ctx.json();
    const allowed = ["name", "coverKey", "isPublic", "exclusive", "categoryId", "hidden", "description", "coverSource", "customCoverKey"];
    const partial = {};
    for (const k of allowed) if (b[k] !== undefined) partial[k] = b[k];
    if (partial.hidden !== undefined) partial.hiddenAt = partial.hidden ? now() : null;
    if (Array.isArray(b.songIds)) partial.songIds = b.songIds;
    const p = docs.patch(PL, ctx.params.id, partial);
    if (!p) fail(404, "Playlist não encontrada.");
    return playlistOut(p, u, true);
  };
  r.patch("/api/playlists/:id", updatePlaylist);
  r.put("/api/playlists/:id", updatePlaylist);
  r.delete("/api/playlists/:id", (ctx) => { requireAdmin(ctx); docs.del(PL, ctx.params.id); return { ok: true }; });
  r.post("/api/playlists/:id/songs", async (ctx) => {
    const u = requireAdmin(ctx);
    const b = await ctx.json();
    const ids = b.songIds || (b.songId ? [b.songId] : []);
    let p;
    for (const sid of ids) p = addSongToPlaylist(ctx.params.id, sid);
    p = p || docs.get(PL, ctx.params.id);
    if (!p) fail(404, "Playlist não encontrada.");
    return playlistOut(p, u, true);
  });
  r.put("/api/playlists/:id/songs", async (ctx) => {
    const u = requireAdmin(ctx);
    const b = await ctx.json();
    const p = docs.patch(PL, ctx.params.id, { songIds: b.songIds || b.ids || [] });
    if (!p) fail(404, "Playlist não encontrada.");
    return playlistOut(p, u, true);
  });
  r.delete("/api/playlists/:id/songs/:songId", (ctx) => {
    const u = requireAdmin(ctx);
    const p = docs.get(PL, ctx.params.id);
    if (!p) fail(404, "Playlist não encontrada.");
    return playlistOut(docs.patch(PL, p.id, { songIds: (p.songIds || []).filter((x) => x !== ctx.params.songId) }), u, true);
  });
  r.put("/api/playlists/:id/favorites", async (ctx) => {
    const u = requireUser(ctx);
    const b = await ctx.json();
    const p = docs.get(PL, ctx.params.id) || docs.get("user-playlists", ctx.params.id);
    if (!p) fail(404, "Playlist não encontrada.");
    let changed = 0;
    for (const sid of p.songIds || []) {
      if (songStats(u.id, sid).favorite !== !!b.favorite) { setSongStats(u.id, sid, { favorite: !!b.favorite }); changed++; }
    }
    return { songIds: p.songIds || [], changed };
  });
  r.put("/api/playlists/visibility", async (ctx) => {
    const u = requireAdmin(ctx);
    const b = await ctx.json();
    const out = [];
    for (const id of b.ids || []) {
      const p = docs.patch(PL, id, { hidden: !!b.hidden, hiddenAt: b.hidden ? now() : null });
      if (p) out.push(playlistOut(p, u));
    }
    return { playlists: out, changed: out.length };
  });
  r.post("/api/playlists/:id/share", (ctx) => {
    requireUser(ctx);
    const p = docs.get(PL, ctx.params.id);
    if (!p) fail(404, "Playlist não encontrada.");
    const s = p.slug || docs.patch(PL, p.id, { slug: slug(10) }).slug;
    const base = config.publicUrl || `${ctx.req.headers["x-forwarded-proto"] || "http"}://${ctx.req.headers.host}`;
    return { slug: s, path: `/p/${s}`, url: `${base}/p/${s}` };
  });
  r.get("/api/share/:slug", (ctx) => {
    const p = docs.list(PL).find((x) => x.slug === ctx.params.slug) || docs.list("user-playlists").find((x) => x.slug === ctx.params.slug);
    if (!p) fail(404, "Link não encontrado.");
    const songs = (p.songIds || []).map((id) => docs.get(SONGS, id)).filter((s) => s && s.status === "ready");
    return { ...playlistOut(p, ctx.user, true), kind: "playlist", playlist: playlistOut(p, ctx.user), songs: songs.map((s) => songOut(s, ctx.user?.id)) };
  });

  // ===================================================================================
  // Armazenamento (resumo)
  // ===================================================================================
  r.get("/api/storage", (ctx) => {
    requireUser(ctx);
    const songs = docs.list(SONGS);
    const used = songs.reduce((a, s) => a + (Number(s.size) || 0), 0);
    return { used, usedBytes: used, songs: songs.length, songCount: songs.length, limit: null, limitBytes: null, quota: null };
  });
}

// ===================================================================================
// Funções auxiliares
// ===================================================================================
export function playlistOut(p, u, withSongs = false) {
  const songs = (p.songIds || []).map((id) => docs.get(SONGS, id)).filter((s) => s && s.status === "ready");
  const first = songs.find((s) => s.coverKey);
  const base = {
    id: p.id, name: p.name, description: p.description || "", slug: p.slug || null,
    coverKey: p.coverKey || null,
    coverUrl: coverUrl(p.coverKey) || coverUrl(first?.coverKey) || null,
    customCoverUrl: coverUrl(p.customCoverKey || p.coverKey),
    coverSource: p.coverSource || (p.coverKey ? "custom" : null),
    isPublic: p.isPublic !== false, exclusive: !!p.exclusive, categoryId: p.categoryId || null,
    hidden: !!p.hidden, hiddenAt: p.hiddenAt || null,
    songIds: songs.map((s) => s.id), songCount: songs.length,
    duration: songs.reduce((a, s) => a + (Number(s.duration) || 0), 0),
    createdAt: p.createdAt, updatedAt: p.updatedAt || p.createdAt,
  };
  if (withSongs) base.songs = songs.map((s) => songOut(s, u?.id));
  return base;
}

export function addSongToPlaylist(pid, sid) {
  const p = docs.get(PL, pid);
  if (!p) return null;
  const ids = p.songIds || [];
  if (ids.includes(sid)) return p;
  return docs.patch(PL, pid, { songIds: [...ids, sid] });
}

function offlineLicense(u) {
  const validUntil = new Date(Date.now() + 30 * 86400e3).toISOString();
  return { planId: null, planName: null, userId: u.id, expiresAt: null, validUntil, offline: { allowed: true, validUntil, syncDays: 30 } };
}

export function streamFile(ctx, file, type) {
  const { req, res } = ctx;
  const stat = fs.statSync(file);
  const total = stat.size;
  const range = req.headers.range;
  const headers = { "Content-Type": type, "Accept-Ranges": "bytes", "Cache-Control": "private, max-age=3600" };
  if (range) {
    const m = /bytes=(\d*)-(\d*)/.exec(range);
    let start = m && m[1] ? Number(m[1]) : 0;
    let end = m && m[2] ? Number(m[2]) : total - 1;
    if (m && !m[1] && m[2]) { start = Math.max(0, total - Number(m[2])); end = total - 1; }
    if (start >= total || end < start) {
      res.writeHead(416, { "Content-Range": `bytes */${total}` });
      res.end();
      return ctx.HANDLED;
    }
    end = Math.min(end, total - 1);
    res.writeHead(206, { ...headers, "Content-Range": `bytes ${start}-${end}/${total}`, "Content-Length": end - start + 1 });
    if (req.method === "HEAD") { res.end(); return ctx.HANDLED; }
    fs.createReadStream(file, { start, end }).pipe(res);
  } else {
    res.writeHead(200, { ...headers, "Content-Length": total });
    if (req.method === "HEAD") { res.end(); return ctx.HANDLED; }
    fs.createReadStream(file).pipe(res);
  }
  return ctx.HANDLED;
}

/** Converte vídeo/áudio para MP3 usando o ffmpeg instalado no servidor. */
function startConversion(songId, publish, playlistId) {
  const id = uuid();
  const conv = docs.put("conversions", id, { songId, status: "running", stage: "Convertendo para MP3…", progress: 0, error: null, createdAt: now() });
  const src = audioPath(songId);
  const tmp = src + ".mp3";
  const song = docs.get(SONGS, songId);
  const total = Number(song?.duration) || 0;
  let proc;
  try {
    proc = spawn(config.ffmpegPath, ["-y", "-i", src, "-vn", "-acodec", "libmp3lame", "-b:a", "192k", "-progress", "pipe:2", "-nostats", tmp]);
  } catch (e) {
    docs.patch("conversions", id, { status: "error", error: "ffmpeg não está instalado no servidor." });
    docs.patch(SONGS, songId, { status: "error" });
    return docs.get("conversions", id);
  }
  proc.on("error", () => {
    docs.patch("conversions", id, { status: "error", error: "ffmpeg não está instalado no servidor (instale com: sudo apt install ffmpeg)." });
    docs.patch(SONGS, songId, { status: "error" });
  });
  proc.stderr.on("data", (d) => {
    const m = /out_time_ms=(\d+)/.exec(d.toString());
    if (m && total) docs.patch("conversions", id, { progress: Math.min(0.99, Number(m[1]) / 1e6 / total) });
  });
  proc.on("close", (code) => {
    if (code === 0 && fs.existsSync(tmp)) {
      fs.renameSync(tmp, src);
      const s = docs.get(SONGS, songId);
      docs.patch(SONGS, songId, { status: publish ? "ready" : "draft", mimeType: "audio/mpeg", size: fs.statSync(src).size, audioVersion: (s?.audioVersion || 0) + 1 });
      if (playlistId) addSongToPlaylist(playlistId, songId);
      docs.patch("conversions", id, { status: "done", progress: 1, stage: "Concluído" });
    } else if (docs.get("conversions", id)?.status !== "error") {
      docs.patch("conversions", id, { status: "error", error: "A conversão para MP3 falhou." });
      docs.patch(SONGS, songId, { status: "error" });
    }
  });
  return conv;
}

export { userAgentDevice };
