// Envio de e-mails pelo Resend (https://resend.com) — usado no "Esqueci minha senha".
import { kvGet, kvSet, kvDel, now } from "./db.js";
import { encrypt, decrypt } from "./mercadopago.js";

const KEY = "email:config";
const API = process.env.RESEND_API_BASE || "https://api.resend.com";

export function emailView() {
  const c = kvGet(KEY, null);
  const envKey = process.env.RESEND_API_KEY;
  const from = c?.from || process.env.EMAIL_FROM || "";
  const hasApiKey = !!(c?.apiKeyEnc || envKey);
  return { configured: hasApiKey && !!from, from, hasApiKey, updatedAt: c?.updatedAt || null, provider: "resend" };
}
export function emailSave({ from, apiKey, clear }) {
  if (clear) { kvDel(KEY); return emailView(); }
  const cur = kvGet(KEY, {}) || {};
  kvSet(KEY, { ...cur, from: String(from || "").trim(), ...(apiKey ? { apiKeyEnc: encrypt(apiKey) } : {}), updatedAt: now() });
  return emailView();
}
const apiKey = () => decrypt(kvGet(KEY, {})?.apiKeyEnc) || process.env.RESEND_API_KEY || null;

/** Envia um e-mail. Devolve true se o Resend aceitou. */
export async function sendEmail({ to, subject, html, text }) {
  const view = emailView();
  const key = apiKey();
  if (!view.configured || !key) return false;
  try {
    const res = await fetch(`${API}/emails`, {
      method: "POST",
      headers: { Authorization: `Bearer ${key}`, "Content-Type": "application/json" },
      body: JSON.stringify({ from: view.from, to: [to], subject, html, text }),
      signal: AbortSignal.timeout(15000),
    });
    if (!res.ok) console.error("[e-mail] Resend recusou:", res.status, (await res.text()).slice(0, 300));
    return res.ok;
  } catch (e) {
    console.error("[e-mail] falha ao enviar:", e.message);
    return false;
  }
}

export async function testEmailKey(key) {
  try {
    const res = await fetch(`${API}/domains`, { headers: { Authorization: `Bearer ${key}` }, signal: AbortSignal.timeout(10000) });
    return res.status !== 401 && res.status !== 403;
  } catch { return true; } // sem conexão para testar: não bloqueia o salvamento
}
