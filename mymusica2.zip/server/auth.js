import crypto from "node:crypto";
import { users, sessions } from "./db.js";
import { config } from "./config.js";
import { parseCookies, fail } from "./http.js";

export const COOKIE = "mm_session";

export function hashPassword(password) {
  const salt = crypto.randomBytes(16).toString("hex");
  const hash = crypto.scryptSync(String(password), salt, 64).toString("hex");
  return `scrypt$${salt}$${hash}`;
}
export function verifyPassword(password, stored) {
  if (!stored) return false;
  const [, salt, hash] = stored.split("$");
  if (!salt || !hash) return false;
  const test = crypto.scryptSync(String(password), salt, 64);
  const ref = Buffer.from(hash, "hex");
  return ref.length === test.length && crypto.timingSafeEqual(ref, test);
}

/** Usuário como o app espera receber (sem dados internos). */
export function publicUser(u) {
  if (!u) return null;
  const { _data, ...rest } = u;
  return rest;
}

function isSecure(req) {
  if (config.cookieSecure !== "auto") return config.cookieSecure;
  return req.headers["x-forwarded-proto"] === "https" || !!req.socket.encrypted;
}

export function startSession(req, res, user) {
  const token = crypto.randomBytes(32).toString("base64url");
  const ip = req.headers["x-forwarded-for"]?.split(",")[0].trim() || req.socket.remoteAddress;
  sessions.create(token, user.id, req.headers["user-agent"] || "", ip);
  const parts = [`${COOKIE}=${token}`, "Path=/", "HttpOnly", "SameSite=Lax", `Max-Age=${60 * 60 * 24 * 365}`];
  if (isSecure(req)) parts.push("Secure");
  res.setHeader("Set-Cookie", parts.join("; "));
  return token;
}

export function endSession(req, res) {
  const token = parseCookies(req)[COOKIE];
  if (token) sessions.remove(token);
  res.setHeader("Set-Cookie", `${COOKIE}=; Path=/; HttpOnly; SameSite=Lax; Max-Age=0`);
}

export function loadSession(req) {
  const token = parseCookies(req)[COOKIE];
  if (!token) return { user: null, session: null };
  const session = sessions.get(token);
  if (!session) return { user: null, session: null };
  const user = users.byId(session.user_id);
  if (!user || user.blocked) return { user: null, session: null };
  // Atualiza "visto por último" no máximo a cada minuto.
  if (Date.now() - new Date(session.last_seen).getTime() > 60_000) sessions.touch(token);
  return { user, session };
}

export const requireUser = (ctx) => { if (!ctx.user) fail(401, "Faça login para continuar."); return ctx.user; };
export const requireAdmin = (ctx) => {
  requireUser(ctx);
  if (ctx.user.role !== "admin") fail(403, "Apenas o administrador pode fazer isso.");
  return ctx.user;
};
