#!/usr/bin/env bash
# Instalação do My Music numa VPS Ubuntu/Debian (ex.: Hostinger).
# Uso, dentro da pasta do projeto:
#   sudo bash deploy/instalar.sh                     -> acesso pelo IP (porta 3000)
#   sudo bash deploy/instalar.sh seudominio.com.br   -> com domínio (Nginx na porta 80)
set -euo pipefail
DOMINIO="${1:-}"
APP_DIR="$(cd "$(dirname "$0")/.." && pwd)"
PORTA="$(grep -E '^PORT=' "$APP_DIR/.env" 2>/dev/null | cut -d= -f2 || true)"; PORTA="${PORTA:-3000}"

if [ "$(id -u)" -ne 0 ]; then echo "Rode como administrador: sudo bash deploy/instalar.sh $DOMINIO"; exit 1; fi
if ! command -v apt-get >/dev/null; then echo "Este instalador é para Ubuntu/Debian."; exit 1; fi

echo "==> 1/6 Pacotes do sistema"
export DEBIAN_FRONTEND=noninteractive
apt-get update -y
apt-get install -y curl ca-certificates git ffmpeg nginx

echo "==> 2/6 Node.js 22"
precisa_node=1
if command -v node >/dev/null; then
  v="$(node -p 'process.versions.node')"; ma="${v%%.*}"; mi="$(echo "$v" | cut -d. -f2)"
  if [ "$ma" -gt 22 ] || { [ "$ma" -eq 22 ] && [ "$mi" -ge 13 ]; }; then precisa_node=0; fi
fi
if [ "$precisa_node" -eq 1 ]; then
  curl -fsSL https://deb.nodesource.com/setup_22.x | bash -
  apt-get install -y nodejs
fi
echo "    Node $(node -v)"

echo "==> 3/6 Configuração e pasta de dados"
mkdir -p "$APP_DIR/data"
if [ ! -f "$APP_DIR/.env" ]; then
  cp "$APP_DIR/.env.example" "$APP_DIR/.env"
  sed -i "s#^APP_SECRET=.*#APP_SECRET=$(head -c 32 /dev/urandom | od -An -tx1 | tr -d ' \n')#" "$APP_DIR/.env"
fi
if [ -n "$DOMINIO" ]; then sed -i "s#^PUBLIC_URL=.*#PUBLIC_URL=https://$DOMINIO#" "$APP_DIR/.env"; fi
chown -R www-data:www-data "$APP_DIR/data" "$APP_DIR/.env"
chmod 600 "$APP_DIR/.env"
node "$APP_DIR/scripts/check.mjs" >/dev/null || { node "$APP_DIR/scripts/check.mjs"; exit 1; }
# O serviço roda como www-data; se a pasta não for acessível para ele (ex.: dentro de /root), roda como root.
USUARIO=www-data
sudo -u www-data test -r "$APP_DIR/server/start.js" 2>/dev/null || USUARIO=root

echo "==> 4/6 Serviço (inicia sozinho com o servidor)"
sed -e "s#/var/www/mymusicas#$APP_DIR#g" -e "s#^User=.*#User=$USUARIO#" "$APP_DIR/deploy/mymusic.service" > /etc/systemd/system/mymusic.service
systemctl daemon-reload
systemctl enable mymusic >/dev/null
systemctl restart mymusic

echo "==> 5/6 Servidor web (Nginx)"
if [ -n "$DOMINIO" ]; then
  sed -e "s/seudominio.com.br/$DOMINIO/g" -e "s/127.0.0.1:3000/127.0.0.1:$PORTA/" "$APP_DIR/deploy/nginx.conf" > /etc/nginx/sites-available/mymusic
  ln -sf /etc/nginx/sites-available/mymusic /etc/nginx/sites-enabled/mymusic
  rm -f /etc/nginx/sites-enabled/default
  nginx -t && systemctl reload nginx
fi
if command -v ufw >/dev/null && ufw status | grep -q "Status: active"; then
  ufw allow OpenSSH >/dev/null; ufw allow 'Nginx Full' >/dev/null || true
  [ -z "$DOMINIO" ] && ufw allow "$PORTA"/tcp >/dev/null
fi

echo "==> 6/6 Conferindo"
for i in $(seq 1 20); do curl -fs "http://127.0.0.1:$PORTA/api/health" >/dev/null && break; sleep 1; done
if curl -fs "http://127.0.0.1:$PORTA/api/health" >/dev/null; then
  echo "✅ My Music está no ar."
else
  echo "❌ O serviço não respondeu. Veja o erro com: journalctl -u mymusic -n 50"; exit 1
fi
IP="$(curl -fs -4 https://ifconfig.me 2>/dev/null || hostname -I | awk '{print $1}')"
if [ -n "$DOMINIO" ]; then
  echo "   Acesse: http://$DOMINIO  (depois ative o HTTPS:)"
  echo "   apt-get install -y certbot python3-certbot-nginx && certbot --nginx -d $DOMINIO"
else
  echo "   Acesse: http://$IP:$PORTA"
  echo "   Se não abrir, libere a porta $PORTA no firewall da Hostinger (painel da VPS → Firewall)."
fi
echo "   No primeiro acesso, crie o administrador (login: admin@gmail.com + a senha que você escolher)."
