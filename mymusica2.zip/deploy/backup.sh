#!/usr/bin/env bash
# Cópia de segurança da pasta de dados (banco, músicas, capas, chave das credenciais).
# Uso: sudo bash deploy/backup.sh   — guarda em backups/ e mantém os 7 mais recentes.
# Restaurar: pare o serviço (systemctl stop mymusic), extraia o arquivo na pasta do projeto e ligue de novo.
# Agendar todo dia às 3h:  (crontab -l 2>/dev/null; echo "0 3 * * * cd $(pwd) && bash deploy/backup.sh") | crontab -
set -euo pipefail
cd "$(dirname "$0")/.."
DATA_DIR="$(grep -E '^DATA_DIR=' .env 2>/dev/null | cut -d= -f2 || true)"; DATA_DIR="${DATA_DIR:-data}"
[ -d "$DATA_DIR" ] || { echo "Pasta de dados não encontrada: $DATA_DIR"; exit 1; }
mkdir -p backups
ARQ="backups/mymusic-$(date +%Y-%m-%d_%H%M).tar.gz"
# cópia consistente do banco, mesmo com o servidor ligado
rm -f "$DATA_DIR/mymusic.backup.db"
node --no-warnings -e "new (require('node:sqlite').DatabaseSync)(process.argv[1]).exec(\"VACUUM INTO '\" + process.argv[2] + \"'\")" "$DATA_DIR/mymusic.db" "$DATA_DIR/mymusic.backup.db"
FILES="$DATA_DIR"; [ -f .env ] && FILES="$FILES .env"
tar czf "$ARQ" --exclude="$DATA_DIR/uploads" --exclude="$DATA_DIR/mymusic.db" --exclude="$DATA_DIR/mymusic.db-wal" --exclude="$DATA_DIR/mymusic.db-shm" \
  --transform "s#mymusic.backup.db#mymusic.db#" $FILES
rm -f "$DATA_DIR/mymusic.backup.db"
ls -1t backups/mymusic-*.tar.gz | tail -n +8 | xargs -r rm -f
echo "Backup salvo em $ARQ ($(du -h "$ARQ" | cut -f1))"
