// PM2 (alternativa ao systemd): pm2 start deploy/ecosystem.config.cjs && pm2 save
module.exports = {
  apps: [{ name: "mymusic", script: "server/start.js", node_args: "--no-warnings", cwd: __dirname + "/..", env: { NODE_ENV: "production" } }],
};
