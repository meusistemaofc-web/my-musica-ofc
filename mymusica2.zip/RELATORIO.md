# Relatório da auditoria — My Music v1.1.0

Data: 04/11/2026

## Resumo

| Item | Resultado |
|---|---|
| Testes automáticos (`npm test`) | **18 de 18 passando** |
| Verificação de arquivos (`npm run check`) | **sem problemas** |
| Telas abertas no navegador sem erro | **77** (61 como administrador, 16 como usuário comum) |
| Rotas da API conferidas quanto a permissão | **todas** (visitante → 401, usuário em rota de admin → 403) |
| Instalação do zero (banco vazio) | **ok** |
| Backup e restauração do banco | **ok** |

## Situação encontrada no pacote original

O `mymusicas-main.zip` continha **apenas o site compilado** (pasta `dist` gerada pelo build), sem:
o código-fonte, o servidor (funções da Netlify, cerca de 350 rotas `/api`), o `package.json` do projeto
e o `manifest.json`. Os arquivos do site também estavam com maiúsculas/minúsculas trocadas
(ex.: o HTML pedia `index-Di-3z8Wk.js`, mas o arquivo era `index-di-3z8wk.js`), o que dá tela branca em servidor Linux.

## O que foi corrigido e reconstruído

**Arquivos do site**
- Nomes dos arquivos corrigidos para bater com o que o HTML e o código pedem.
- `manifest.json` criado (instalação como app no celular).

**Servidor (reconstruído do zero, a partir do que o app espera)**
- Autenticação: configuração do administrador, cadastro, login, sessões, troca e redefinição de senha, aprovação de cadastros, bloqueio de contas.
- Biblioteca: envio de músicas em partes com retomada, conversão MP4→MP3, streaming com avanço/retrocesso, download, ouvir offline, capas, favoritas, histórico, categorias, playlists e compartilhamento.
- Painel: usuários, sessões, suporte, playlists dos usuários, identidade visual, cores, tela inicial.
- Mercado Pago, publicidade paga com Pix e Rádio ao Vivo completos (ver README).

**Nesta auditoria final**
- **E-mail de "Esqueci minha senha"** agora é enviado de verdade (Resend), configurável pelo painel *Usuários → Envio de e-mails*. Antes só aparecia no log.
- **Proteção contra força bruta:** limite de tentativas por IP no login (10 a cada 10 min), cadastro, recuperação e redefinição de senha.
- **Envio grande demais** agora responde "Arquivo grande demais" (413) em vez de derrubar a conexão.
- **Cabeçalhos de segurança:** `X-Frame-Options`, `Permissions-Policy` (microfone só para o próprio site, usado no estúdio da rádio), `X-Content-Type-Options`, `Referrer-Policy`.
- **Nginx:** IP real do visitante repassado sem permitir falsificação (o limite de tentativas não pode ser burlado), compressão gzip, envios grandes direto para o app, limite de 25 MB.
- **Verificação da versão do Node** antes de iniciar, com mensagem clara se estiver antiga (novo `server/start.js`).
- **Manutenção diária automática:** remove sessões muito antigas, links de senha vencidos e envios de música abandonados (libera espaço em disco).
- **Encerramento limpo** do banco ao reiniciar o serviço; erros não tratados ficam registrados no log.
- **Backup consistente:** `deploy/backup.sh` copia o banco com segurança mesmo com o servidor ligado (testado: backup extraído e lido com sucesso) e guarda os 7 mais recentes.
- **Atualização segura:** `deploy/atualizar.sh` faz backup, baixa do GitHub, confere os arquivos, reinicia e confirma que voltou.
- **Instalador revisado** para a VPS da Hostinger: confere a versão do Node, gera `APP_SECRET` aleatório, protege o `.env` (permissão 600), ajusta o firewall (ufw) se estiver ativo, testa se o app respondeu e mostra o endereço de acesso.
- **Diagnóstico:** `deploy/diagnostico.sh` mostra Node, ffmpeg, serviço, Nginx, saúde do app, disco e últimos erros.
- **Testes automáticos** (`test/`) cobrindo servidor, arquivos do site, autenticação, permissões de todas as rotas, biblioteca, streaming, painel, suporte, Mercado Pago (com simulador), publicidade, rádio (incluindo a transmissão HLS), persistência após reinício e segurança.
- **GitHub Actions** (`.github/workflows/testes.yml`): os testes rodam sozinhos a cada envio ao GitHub.
- `.gitattributes` para manter os scripts `.sh` funcionando mesmo se enviados pelo Windows; `.gitignore` inclui `backups/`.
- `Dockerfile` com verificação de saúde; serviço systemd com reinício automático.

## Sobre o `package.json` e as dependências

O `package.json` foi reconstruído com scripts (`start`, `dev`, `test`, `check`, `backup`), versão mínima do
Node e ponto de entrada. **A lista de dependências está vazia de propósito, e isso é o correto:** o servidor
usa apenas módulos que já vêm no Node.js 22 (`http`, `crypto`, `sqlite`, `fs`, `child_process`, `test`).
Não há `npm install`, nem pasta `node_modules`, nem risco de pacote desatualizado ou quebrado.
O site em `public/` já vem compilado, com React, hls.js e lamejs embutidos.

Dependências do **sistema** (o instalador instala todas): Node.js 22, Nginx, ffmpeg (opcional), git, curl.

## Configurações externas que você ainda precisa fornecer

| O quê | Onde | Obrigatório? |
|---|---|---|
| Criar a conta de administrador | Primeiro acesso ao site | **Sim** |
| Domínio apontado para o IP da VPS (registro A) | Painel do domínio (Hostinger/registro.br) | Para HTTPS e Mercado Pago |
| HTTPS (certbot) | Comando no README, seção 2 | Para HTTPS e Mercado Pago |
| Liberar portas 80/443 (e 3000 se usar pelo IP) | Hostinger → VPS → Firewall | Se o firewall estiver ativo |
| Access Token e Public Key do Mercado Pago | Painel → Mercado Pago | Para vender anúncios |
| URL de notificação + assinatura secreta (webhook) | Painel do Mercado Pago → Webhooks | Recomendado |
| Pacotes de publicidade (nome, dias, preço) | Painel → Publicidade | Para vender anúncios |
| Chave de API do Resend + remetente | Painel → Usuários → Envio de e-mails | Para o "Esqueci minha senha" por e-mail |
| Backup automático diário (cron) | Comando no README, seção 2 | Recomendado |

## Limitações conhecidas (honestamente)

- **Não testado com contas reais** do Mercado Pago e do Resend: o ambiente da auditoria não tem acesso à internet,
  então as integrações foram testadas com simuladores fiéis às APIs oficiais. Faça o primeiro teste no **modo Teste**
  do Mercado Pago antes de mudar para Produção.
- **Instalador não executado numa VPS real** (mesmo motivo); a sintaxe e cada etapa foram revisadas, e o servidor,
  o backup e a restauração foram testados de verdade.
- **Recursos que não existiam no pacote** e continuam indisponíveis (o app mostra aviso, não quebra): planos pagos/
  assinaturas, vinhetas e presentes pagos na rádio, anúncios com vídeo/áudio, notificações push, indicação,
  backup pelo app, recebimento de músicas por link, assistente de voz, localização e membros exclusivos.
- A rádio automática toca **somente MP3** (o próprio app já avisa isso na tela da playlist).
