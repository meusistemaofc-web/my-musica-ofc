# 🎧 My Music

Biblioteca de músicas, playlists, **Rádio ao Vivo** e **publicidade paga com Pix** — tudo num só sistema.
Este repositório tem o app completo: o site (pasta `public/`) e o servidor/API (pasta `server/`).

- **Sem dependências para instalar:** o servidor usa só recursos do próprio Node.js (não precisa de `npm install`).
- **Banco de dados:** SQLite embutido no Node, num único arquivo (`data/mymusic.db`).
- **Requisitos:** Node.js **22.13 ou mais novo**. Opcionais: `ffmpeg` (converter vídeo MP4 em MP3) e Nginx (domínio com HTTPS).

> 📄 O que foi verificado e corrigido está em **[RELATORIO.md](RELATORIO.md)**.

---

## 1. Subir para o GitHub

**Pelo navegador (mais fácil):**
1. Em github.com, clique em **New repository**, dê o nome `mymusicas` e crie.
2. Clique em **uploading an existing file**.
3. Extraia o zip e arraste **o conteúdo** da pasta `mymusicas` (não a pasta em si). Confirme em **Commit changes**.

**Pelo terminal:**
```bash
git init && git add . && git commit -m "My Music"
git branch -M main
git remote add origin https://github.com/SEU_USUARIO/mymusicas.git
git push -u origin main
```

> A pasta `data/` (banco e músicas), `backups/` e o arquivo `.env` **nunca** vão para o GitHub. Isso é intencional.

---

## 2. Instalar na VPS da Hostinger (Ubuntu)

1. No painel da Hostinger, abra a VPS (sistema **Ubuntu 22.04 ou 24.04**) e clique em **Terminal do navegador**.
2. Cole, trocando `SEU_USUARIO`:
```bash
git clone https://github.com/SEU_USUARIO/mymusicas.git /var/www/mymusicas
cd /var/www/mymusicas
sudo bash deploy/instalar.sh
```
3. Ao terminar aparece **"✅ My Music está no ar"** e o endereço. Abra `http://IP_DA_VPS:3000`.
   Se não abrir, libere a porta 3000 em **VPS → Firewall** no painel da Hostinger.
4. No primeiro acesso, crie o administrador. O login é **admin@gmail.com** + a senha que você escolher.

### Com domínio e HTTPS (necessário para o Mercado Pago confirmar pagamentos)
1. No DNS do domínio, crie um registro **A** com nome `@` apontando para o IP da VPS (e outro `www`, se quiser).
2. Depois que o domínio abrir no navegador (pode levar algumas horas), rode:
```bash
cd /var/www/mymusicas && sudo bash deploy/instalar.sh seudominio.com.br
sudo apt-get install -y certbot python3-certbot-nginx && sudo certbot --nginx -d seudominio.com.br -d www.seudominio.com.br
```

### Comandos do dia a dia
| Para quê | Comando |
|---|---|
| Ver se está tudo bem | `sudo bash deploy/diagnostico.sh` |
| Atualizar depois de mudar no GitHub | `sudo bash deploy/atualizar.sh` (faz backup antes) |
| Fazer backup agora | `sudo bash deploy/backup.sh` |
| Reiniciar | `sudo systemctl restart mymusic` |
| Ver o log ao vivo | `sudo journalctl -u mymusic -f` |

**Backup automático todo dia às 3h:**
```bash
(crontab -l 2>/dev/null; echo "0 3 * * * cd /var/www/mymusicas && bash deploy/backup.sh") | crontab -
```
Restaurar: `sudo systemctl stop mymusic`, extraia o arquivo de `backups/` dentro da pasta do projeto, `sudo systemctl start mymusic`.

---

## 3. Outras formas de rodar

```bash
npm start            # qualquer sistema com Node 22.13+  →  http://localhost:3000
npm test             # roda os testes automáticos
npm run check        # confere arquivos e sintaxe
docker compose up -d --build                 # Docker
pm2 start deploy/ecosystem.config.cjs        # PM2
```

---

## 4. Configuração (`.env`)

O instalador cria o `.env` a partir do `.env.example`. Tudo tem valor padrão.

| Variável | Para que serve |
|---|---|
| `PORT` | Porta do servidor (padrão 3000) |
| `DATA_DIR` | Pasta de dados — **faça backup** |
| `PUBLIC_URL` | Endereço público com https (links de compartilhar, senha e Mercado Pago) |
| `APP_SECRET` | Chave que criptografa as credenciais. O instalador gera; **não troque depois** |
| `COOKIE_SECURE` | `auto` (recomendado) |
| `FFMPEG_PATH` | Caminho do ffmpeg |
| `RESEND_API_KEY` / `EMAIL_FROM` | Opcional: e-mail sem usar o painel |

---

## 5. Configurações feitas no painel do app

**E-mail ("Esqueci minha senha")** — *Painel → Usuários → Envio de e-mails*: crie uma conta grátis em
[resend.com](https://resend.com), verifique seu domínio, gere uma **API Key** e cole com o remetente
(ex.: `My Music <nao-responda@seudominio.com.br>`). Sem isso, o link de senha aparece no log
(`sudo journalctl -u mymusic | grep senha`) e o admin pode gerar o link em *Usuários*.

**Mercado Pago (publicidade paga com Pix)** — *Painel → Mercado Pago*:
1. Em [mercadopago.com.br/developers/panel/app](https://www.mercadopago.com.br/developers/panel/app) crie uma aplicação.
2. Cole **Access Token** e **Public Key** (comece com as de **teste**, `TEST-…`) e salve: deve aparecer "Conectado como …".
3. Copie a **URL de notificação** mostrada na tela e cole no Mercado Pago em *Webhooks* (evento **Pagamentos**).
   Copie a **assinatura secreta** de lá e cole no My Music.
4. Em *Painel → Publicidade*, cadastre os pacotes (nome, dias, preço).

Fluxo: anunciante cria o anúncio → paga o Pix → pagamento confirmado sozinho → você aprova, pede correção
ou rejeita → aprovado, ele aparece em tela cheia pelo período contratado.

**Rádio ao Vivo** — *Painel → Rádio*:
1. Ligue "Disponibilizar Rádio para os usuários" e escolha quem ouve (todos ou usuários escolhidos).
2. **Playlist da Rádio** → crie com músicas da biblioteca → **Tocar playlist** (o servidor transmite sozinho).
3. **Programação** → programas com dias e horários entram e saem do ar sozinhos.
4. **Estúdio** → fale ao vivo pelo microfone do navegador. **Bate-papo** → modere mensagens.

> A rádio automática toca músicas em **MP3**. Se o servidor reiniciar, ela volta ao ar sozinha.

---

## 6. O que funciona

✅ Administrador, cadastro, login, sessões, troca e redefinição de senha (por e-mail), aprovação de cadastros  
✅ Envio de músicas (até 200 MB, em partes, com retomada), MP4 → MP3, streaming, download, ouvir offline, capas  
✅ Favoritas, histórico, categorias, playlists da biblioteca, link público de playlist, playlists dos usuários  
✅ Suporte (chamados com anexos), usuários e sessões, logo, ícone, cores, tela inicial, instalação como app (PWA)  
✅ Mercado Pago: conexão teste/produção, formas de pagamento, Pix, webhook com assinatura, conferência automática  
✅ Publicidade paga: página de vendas editável, pacotes, pedidos com imagem, Pix, aprovação/correção/rejeição, pausa, exibição, relatório  
✅ Rádio ao Vivo: playlists, transmissão automática, programação, várias rádios ao mesmo tempo, fila editável, estúdio com microfone, bate-papo e acesso

**Ainda não disponíveis** (o app mostra aviso e não quebra): planos pagos/assinaturas, áudios do estúdio (vinhetas)
e presentes/pedidos pagos na rádio, anúncios com vídeo e em áudio, notificações push, programa de indicação,
backup pelo app, recebimento de músicas por link, assistente de voz, localização, membros exclusivos.
O app original veio só com o site compilado; esses recursos dependem de código de servidor que não estava no pacote.

---

## 7. Estrutura

```
public/              Site do app (já compilado)
server/start.js      Início: confere a versão do Node e liga o servidor
server/server.js     Servidor HTTP (site + API), segurança e manutenção diária
server/routes/       API: core, admin, payments, advertising, radio, extras
server/db.js         Banco SQLite      server/radio-engine.js  Transmissão da rádio (HLS)
server/mercadopago.js  Mercado Pago    server/email.js        E-mail (Resend)
test/                Testes automáticos (npm test)
scripts/check.mjs    Verificação rápida (npm run check)
deploy/              instalar, atualizar, backup, diagnóstico, systemd, Nginx, PM2
```
