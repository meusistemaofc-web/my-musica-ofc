// Testes de ponta a ponta do My Music. Rode com: npm test
import { test, before, after } from "node:test";
import assert from "node:assert/strict";
import fs from "node:fs";
import path from "node:path";
import crypto from "node:crypto";
import { startMocks, startServer, client, uploadSong, FIX, ROOT } from "./helpers.mjs";

let mocks, srv, admin, user, anon, song, song2;
const PASS = "senha-forte-123";

before(async () => {
  mocks = await startMocks();
  srv = await startServer(mocks.port);
  admin = client(srv.base);
  user = client(srv.base);
  anon = client(srv.base);
});
after(async () => {
  await srv?.stop();
  await mocks?.close();
  if (process.env.KEEP_DATA !== "1") fs.rmSync(srv.dataDir, { recursive: true, force: true });
});

// ------------------------------------------------------------------ servidor e arquivos
test("servidor responde e entrega o app", async () => {
  const h = await anon.get("/api/health");
  assert.equal(h.status, 200);
  assert.equal(h.data.ok, true);
  for (const p of ["/", "/biblioteca", "/admin/usuarios", "/radio", "/redefinir-senha?token=x"]) {
    const r = await anon.get(p);
    assert.equal(r.status, 200, p);
    assert.match(r.data.toString(), /<div id="root">/);
  }
  const html = fs.readFileSync(path.join(ROOT, "public/index.html"), "utf8");
  for (const ref of html.matchAll(/(?:src|href)="(\/[^"?#]+)"/g)) {
    const r = await anon.get(ref[1]);
    assert.equal(r.status, 200, `arquivo citado no index.html: ${ref[1]}`);
  }
  for (const f of ["/manifest.json", "/sw.js", "/icon-192.png", "/icon-512.png", "/assets/hls-D9b4QHpD.js", "/assets/lamejs-DxgK9G4m.js"]) {
    assert.equal((await anon.get(f)).status, 200, f);
  }
  assert.equal((await anon.get("/assets/nao-existe.js")).status, 404);
  assert.equal((await anon.get("/../server/config.js")).status, 200); // devolve o index (SPA), nunca o código do servidor
  assert.doesNotMatch((await anon.get("/../server/config.js")).data.toString(), /process\.env/);
  const r = await anon.get("/");
  assert.equal(r.headers.get("x-frame-options"), "SAMEORIGIN");
});

// ------------------------------------------------------------------ autenticação
test("configuração inicial do administrador", async () => {
  const s = await anon.get("/api/auth/session");
  assert.equal(s.data.setupRequired, true);
  assert.equal((await admin.post("/api/auth/setup", { email: "admin@gmail.com", password: "123" })).status, 400);
  const ok = await admin.post("/api/auth/setup", { email: "admin@gmail.com", password: PASS, displayName: "Admin" });
  assert.equal(ok.status, 200);
  assert.equal(ok.data.user.role, "admin");
  assert.equal((await anon.post("/api/auth/setup", { email: "x@x.com", password: PASS })).status, 409);
  const me = await admin.get("/api/auth/session");
  assert.equal(me.data.user.email, "admin@gmail.com");
  assert.equal(me.data.setupRequired, false);
});

test("cadastro, login, troca e redefinição de senha", async () => {
  assert.equal((await user.post("/api/auth/signup", { email: "bad", password: PASS })).status, 400);
  const su = await user.post("/api/auth/signup", { email: "ouvinte@teste.com", password: PASS, confirm: PASS, displayName: "Ouvinte" });
  assert.equal(su.status, 200);
  assert.equal(su.data.user.role, "user");
  assert.equal((await anon.post("/api/auth/signup", { email: "ouvinte@teste.com", password: PASS, confirm: PASS })).status, 409);
  await user.post("/api/auth/logout");
  assert.equal((await user.get("/api/auth/session")).data.user, null);
  assert.equal((await user.post("/api/auth/login", { email: "ouvinte@teste.com", password: "errada" })).status, 401);
  assert.equal((await user.post("/api/auth/login", { email: "OUVINTE@teste.com", password: PASS })).status, 200);
  assert.equal((await user.post("/api/auth/password", { current: "errada", password: "nova-senha-123" })).status, 400);
  assert.equal((await user.post("/api/auth/password", { current: PASS, password: "nova-senha-123" })).status, 200);

  // e-mail pelo Resend
  const cfg = await admin.put("/api/admin/email", { from: "My Music <nao-responda@teste.com>", apiKey: "re_teste" });
  assert.equal(cfg.status, 200);
  assert.equal(cfg.data.configured, true);
  assert.equal((await anon.post("/api/auth/forgot", { email: "ouvinte@teste.com" })).status, 200);
  const mail = mocks.emails.at(-1);
  assert.ok(mail, "o e-mail de redefinição deve ser enviado");
  const token = /token=([a-f0-9]+)/.exec(mail.text)[1];
  assert.equal((await anon.post("/api/auth/reset", { token: "invalido", password: PASS })).status, 400);
  const reset = await anon.post("/api/auth/reset", { token, password: PASS });
  assert.equal(reset.status, 200);
  assert.equal((await anon.post("/api/auth/reset", { token, password: PASS })).status, 400, "o link só vale uma vez");
  await anon.post("/api/auth/logout");
  assert.equal((await user.post("/api/auth/login", { email: "ouvinte@teste.com", password: PASS })).status, 200);
});

test("perfil do usuário", async () => {
  const me = await user.get("/api/me");
  assert.equal(me.status, 200);
  const up = await user.patch("/api/me", { displayName: "Ouvinte Fiel", settings: { recordHistory: true } });
  assert.equal(up.data.displayName, "Ouvinte Fiel");
  assert.equal(up.data.settings.recordHistory, true);
});

// ------------------------------------------------------------------ proteção das rotas
test("rotas protegidas: visitante e usuário comum não acessam o que não devem", async () => {
  const routes = (await anon.get("/api/__routes")).data;
  assert.ok(routes.length > 150, "rotas registradas");
  const PUBLIC = [/^\/api\/auth\//, /^\/api\/branding/, /^\/api\/appearance$/, /^\/api\/covers\/:key$/, /^\/api\/files\/:key$/,
    /^\/api\/share\/:slug$/, /^\/api\/public\//, /^\/api\/radio\/public$/, /^\/api\/payments\/webhook$/];
  const fill = (p) => p.replace(/:(\w+)/g, (_, k) => (k === "seg" ? "seg-0.mp3" : k === "n" || k === "seq" ? "0" : "00000000-0000-0000-0000-000000000000"));
  const problems = [];
  for (const r of routes) {
    if (PUBLIC.some((re) => re.test(r.pattern))) continue;
    const url = fill(r.pattern);
    const call = (c) => c[r.method === "DELETE" ? "del" : r.method.toLowerCase()](url, r.method === "GET" ? undefined : {});
    const a = await call(anon);
    if (a.status !== 401) problems.push(`visitante ${r.method} ${r.pattern} → ${a.status}`);
    if (r.pattern.startsWith("/api/admin") || r.pattern.startsWith("/api/radio/admin")) {
      const u = await call(user);
      if (u.status !== 403) problems.push(`usuário ${r.method} ${r.pattern} → ${u.status}`);
    }
  }
  // rotas de administração fora de /api/admin que só o admin pode usar
  for (const [m, u] of [["post", "/api/songs"], ["post", "/api/playlists"], ["post", "/api/categories"], ["put", "/api/branding"],
    ["put", "/api/appearance"], ["post", "/api/plans"], ["put", "/api/ads-global"], ["delete", "/api/songs/x"]]) {
    const res = await user[m === "delete" ? "del" : m](u, {});
    if (res.status !== 403) problems.push(`usuário ${m.toUpperCase()} ${u} → ${res.status}`);
  }
  assert.deepEqual(problems, []);
});

// ------------------------------------------------------------------ biblioteca
test("envio de música, biblioteca, streaming e download", async () => {
  const mp3 = path.join(FIX, "tone.mp3");
  assert.equal((await admin.post("/api/songs", { size: 0 })).status, 400);
  song = await uploadSong(admin, mp3, { title: "Lá 440", artist: "Teste", album: "Sons" });
  song2 = await uploadSong(admin, mp3, { title: "Segunda", artist: "Teste" });
  assert.equal(song.status, "ready");
  const list = await user.get("/api/songs");
  assert.equal(list.data.length, 2);
  const size = fs.statSync(mp3).size;
  const full = await user.get(`/api/songs/${song.id}/stream`);
  assert.equal(full.status, 200);
  assert.equal(full.data.length, size);
  const part = await user.get(`/api/songs/${song.id}/stream`, { Range: "bytes=100-199" });
  assert.equal(part.status, 206);
  assert.equal(part.data.length, 100);
  assert.equal(part.headers.get("content-range"), `bytes 100-199/${size}`);
  assert.equal((await user.get(`/api/songs/${song.id}/stream`, { Range: `bytes=${size + 10}-` })).status, 416);
  const dl = await user.get(`/api/songs/${song.id}/download`);
  assert.match(dl.headers.get("content-disposition"), /attachment/);
  assert.equal((await anon.get(`/api/songs/${song.id}/stream`)).status, 401);

  // capa
  const cover = await admin.post("/api/covers", fs.readFileSync(path.join(FIX, "cover.png")), { "Content-Type": "image/png" });
  assert.equal(cover.status, 200);
  const edit = await admin.patch(`/api/songs/${song.id}`, { coverKey: cover.data.key, title: "Lá 440 Hz" });
  assert.equal(edit.data.title, "Lá 440 Hz");
  assert.equal((await anon.get(edit.data.coverUrl)).status, 200);
  assert.equal((await user.patch(`/api/songs/${song.id}`, { title: "hack" })).status, 403);
  // envio incompleto é recusado
  const half = await admin.post("/api/songs", { mimeType: "audio/mpeg", size: 9_000_000 });
  assert.equal((await admin.post(`/api/songs/${half.data.id}/complete`, {})).status, 400);
  await admin.del(`/api/songs/${half.data.id}`);
});

test("favoritas, histórico, categorias e playlists", async () => {
  const fav = await user.patch(`/api/songs/${song.id}`, { favorite: true });
  assert.equal(fav.data.favorite, true);
  assert.equal((await admin.get("/api/songs")).data.find((s) => s.id === song.id).favorite, false, "favorita é por usuário");
  await user.post("/api/plays", { songId: song.id });
  const plays = await user.get("/api/plays?limit=10");
  assert.equal(plays.data[0].song.id, song.id);
  assert.equal((await user.get("/api/songs")).data.find((s) => s.id === song.id).playCount, 1);

  const cat = await admin.post("/api/categories", { name: "Pop" });
  await admin.put(`/api/songs/${song.id}/categories`, { categoryIds: [cat.data.id] });
  const cats = await user.get("/api/categories");
  assert.deepEqual(cats.data.songs[song.id], [cat.data.id]);
  assert.equal((await user.get(`/api/categories/${cat.data.id}`)).data.songs.length, 1);

  const pl = await admin.post("/api/playlists", { name: "Favoritas da casa" });
  await admin.post(`/api/playlists/${pl.data.id}/songs`, { songIds: [song.id, song2.id] });
  const got = await user.get(`/api/playlists/${pl.data.id}`);
  assert.equal(got.data.songs.length, 2);
  const share = await user.post(`/api/playlists/${pl.data.id}/share`);
  const pub = await anon.get(`/api/share/${share.data.slug}`);
  assert.equal(pub.status, 200);
  assert.equal(pub.data.songs.length, 2);

  // playlists dos usuários
  const up = await user.post("/api/user-playlists", { name: "Minha lista", songIds: [song.id] });
  assert.equal(up.status, 200);
  assert.equal(up.data.playlist.songCount, 1);
  const mine = await user.get("/api/user-playlists");
  assert.equal(mine.data.mine.length, 1);
  assert.equal((await admin.get(`/api/user-playlists/${up.data.playlist.id}`)).status, 200);
  assert.equal((await anon.get(`/api/user-playlists/${up.data.playlist.id}`)).status, 401);
});

// ------------------------------------------------------------------ painel administrativo
test("painel: usuários, aprovação de cadastros, sessões e bloqueio", async () => {
  const list = await admin.get("/api/admin/users");
  assert.equal(list.data.length, 2);
  await admin.put("/api/admin/access", { required: true });
  const novo = client(srv.base);
  const su = await novo.post("/api/auth/signup", { email: "novo@teste.com", password: PASS, confirm: PASS });
  assert.equal(su.data.user.access, "pending");
  assert.equal((await admin.get("/api/admin/access")).data.pending, 1);
  const ap = await admin.put(`/api/admin/users/${su.data.user.id}/approval`, { access: "approved" });
  assert.equal(ap.data.access, "approved");
  await admin.put("/api/admin/access", { required: false });
  const link = await admin.post(`/api/admin/users/${su.data.user.id}/reset-link`);
  assert.match(link.data.url, /redefinir-senha\?token=/);
  const sess = await admin.get("/api/admin/sessions");
  assert.ok(sess.data.sessions.length >= 2);
  await admin.patch(`/api/admin/users/${su.data.user.id}`, { blocked: true });
  assert.equal((await novo.get("/api/me")).status, 401, "conta bloqueada perde a sessão");
  assert.equal((await novo.post("/api/auth/login", { email: "novo@teste.com", password: PASS })).status, 403);
  assert.equal((await admin.del(`/api/admin/users/${list.data.find((u) => u.role === "admin").id}`)).status, 400, "admin não se exclui");
});

test("identidade visual, cores e tela inicial", async () => {
  const cover = await admin.post("/api/covers", fs.readFileSync(path.join(FIX, "cover.png")), { "Content-Type": "image/png" });
  const b = await admin.put("/api/branding", { logo: { key: cover.data.key, width: 64, height: 64 } });
  assert.equal(b.data.logo.url, `/api/covers/${cover.data.key}`);
  assert.equal((await admin.put("/api/appearance", { colors: { primary: "red" } })).status, 400);
  const colors = { primary: "#112233", secondary: "#112233", highlight: "#112233", button: "#112233", text: "#ffffff", background: "#000000", card: "#111111", border: "#222222", icon: "#333333" };
  assert.equal((await admin.put("/api/appearance", { colors })).data.custom, true);
  assert.equal((await anon.get("/api/appearance")).data.colors.primary, "#112233");
  assert.equal((await admin.put("/api/admin/home-screen", { start: "radio", swipe: true })).data.settings.start, "radio");
});

test("suporte: chamado do usuário e resposta do administrador", async () => {
  assert.equal((await user.post("/api/support/tickets", { subject: "Oi", body: "curto" })).status, 400);
  const t = await user.post("/api/support/tickets", { subject: "Não toca", category: "tecnico", body: "A música não começa a tocar." });
  assert.equal(t.status, 200);
  const id = t.data.ticket.id;
  assert.equal((await admin.get("/api/admin/support/summary")).data.unread, 1);
  await admin.post(`/api/admin/support/tickets/${id}/messages`, { body: "Já corrigimos!", status: "answered" });
  const view = await user.get(`/api/support/tickets/${id}`);
  assert.equal(view.data.ticket.status, "answered");
  assert.equal(view.data.messages.filter((m) => m.kind === "message").length, 2);
  const outro = client(srv.base);
  await outro.post("/api/auth/signup", { email: "curioso@teste.com", password: PASS, confirm: PASS });
  assert.equal((await outro.get(`/api/support/tickets/${id}`)).status, 404, "um usuário não vê o chamado do outro");
});

// ------------------------------------------------------------------ Mercado Pago e publicidade
test("Mercado Pago: credenciais, Pix, webhook assinado e aprovação do anúncio", async () => {
  assert.equal((await admin.put("/api/admin/payments", { mode: "production", accessToken: "TEST-1" })).status, 400);
  const bad = await admin.put("/api/admin/payments", { mode: "test", accessToken: "INVALIDO", publicKey: "TEST-pk" });
  assert.equal(bad.data.status, "error");
  const mp = await admin.put("/api/admin/payments", { mode: "test", accessToken: "TEST-123-abc", publicKey: "TEST-pk", webhookSecret: "segredo" });
  assert.equal(mp.data.status, "connected");
  assert.equal(mp.data.account.nickname, "LOJA_TESTE");
  assert.ok(!JSON.stringify(mp.data).includes("TEST-123-abc"), "o token nunca volta inteiro");
  const stored = fs.readFileSync(path.join(srv.dataDir, "mymusic.db")).toString("latin1");
  assert.ok(!stored.includes("TEST-123-abc"), "o token fica criptografado no banco");

  const pkg = await admin.post("/api/admin/advertising/packages", { name: "Start", durationDays: 7, priceCents: 2990, active: true });
  assert.equal(pkg.status, 200);
  const info = await user.get("/api/advertising");
  assert.equal(info.data.pix.available, true);
  const o = await user.post("/api/advertising/orders", { advertiserName: "Loja", email: "loja@teste.com", whatsapp: "11912345678",
    packageId: pkg.data.id, title: "Promoção", description: "Descontos toda semana", buttonText: "Comprar", buttonUrl: "loja.com.br" });
  assert.equal(o.status, 200);
  const id = o.data.order.id;
  assert.equal((await user.post(`/api/advertising/orders/${id}/pix`)).status, 400, "precisa de imagem antes de pagar");
  const img = await user.put(`/api/advertising/orders/${id}/image`, fs.readFileSync(path.join(FIX, "cover.png")), { "Content-Type": "application/octet-stream" });
  assert.equal(img.status, 200);
  assert.equal((await user.put(`/api/advertising/orders/${id}/image`, Buffer.from("isto não é imagem"), { "Content-Type": "application/octet-stream" })).status, 400);
  const pix = await user.post(`/api/advertising/orders/${id}/pix`);
  assert.equal(pix.data.order.payment.status, "pending");
  assert.match(pix.data.order.payment.checkoutData.qrCode, /PIXTESTE/);
  const mpId = pix.data.order.payment.mpPaymentId;

  mocks.approve(mpId);
  const url = `/api/payments/webhook?type=payment&data.id=${mpId}`;
  assert.equal((await anon.post(url, {}, { "x-signature": "ts=1,v1=errado" })).status, 401, "assinatura falsa é recusada");
  const ts = "1700000000";
  const v1 = crypto.createHmac("sha256", "segredo").update(`id:${mpId};request-id:r1;ts:${ts};`).digest("hex");
  assert.equal((await anon.post(url, {}, { "x-signature": `ts=${ts},v1=${v1}`, "x-request-id": "r1" })).status, 200);
  const paid = await user.get(`/api/advertising/orders/${id}`);
  assert.equal(paid.data.order.status, "pending_review");
  assert.ok(paid.data.order.paidAt);

  assert.equal((await admin.post(`/api/admin/advertising/orders/${id}/reject`, {})).status, 400, "rejeitar exige motivo");
  const ok = await admin.post(`/api/admin/advertising/orders/${id}/approve`, {});
  assert.equal(ok.data.order.displayStatus, "active");
  const live = await user.get("/api/advertising/live");
  assert.equal(live.data.ads.length, 1);
  const report = await admin.get("/api/admin/advertising/report");
  assert.equal(report.data.revenueCents, 2990);
  await admin.put("/api/ads-global", { enabled: false });
  assert.equal((await user.get("/api/advertising/live")).data.ads.length, 0, "chave geral desliga a exibição");
});

// ------------------------------------------------------------------ rádio
test("rádio: playlist no ar, transmissão HLS, bate-papo e acesso", async () => {
  assert.equal((await user.get("/api/radio")).data.available, false, "rádio começa desligada");
  await admin.put("/api/radio/admin/settings", { usersEnabled: true, access: "all" });
  const pl = await admin.post("/api/radio/admin/playlists", { name: "Manhã", trackIds: [song.id, song2.id], playMode: "repeat" });
  assert.equal(pl.data.tracks.filter((t) => t.problem).length, 0);
  const start = await admin.post(`/api/radio/admin/playlists/${pl.data.playlist.id}/start`, {});
  assert.equal(start.status, 200);
  const info = await user.get("/api/radio");
  assert.equal(info.data.available, true);
  assert.equal(info.data.stations.length, 1);
  const st = info.data.stations[0];
  assert.equal(st.nowPlaying.title, "Lá 440 Hz");
  const m3u8 = (await user.get(st.playlistUrl)).data.toString();
  assert.match(m3u8, /#EXTM3U/);
  const seg = /(seg-\d+\.mp3)/.exec(m3u8)[1];
  const audio = await user.get(st.playlistUrl.replace("live.m3u8", seg));
  assert.equal(audio.status, 200);
  assert.equal(audio.headers.get("content-type"), "audio/mpeg");
  assert.equal(audio.data.subarray(0, 3).toString(), "ID3", "trecho com carimbo de tempo do HLS");
  assert.equal((await anon.get(st.playlistUrl)).status, 401);

  const auto = await admin.get("/api/radio/admin/auto");
  assert.equal(auto.data.live.program, "Manhã");
  assert.equal((await admin.post("/api/radio/admin/auto/pause", { sessionId: st.sessionId })).data.live.paused, true);
  assert.equal((await admin.post("/api/radio/admin/auto/resume", { sessionId: st.sessionId })).data.live.paused, false);

  assert.equal((await user.post("/api/radio/chat", { text: "Bom dia, rádio!" })).status, 200);
  assert.equal((await user.post("/api/radio/chat", { text: "Bom dia, rádio!" })).status, 429, "anti-spam");
  const chat = await admin.get("/api/radio/admin/chat");
  const me = (await user.get("/api/me")).data;
  assert.equal(chat.data.messages.at(-1).userId, me.id);
  await admin.post("/api/radio/admin/bans", { userId: me.id, minutes: 5, reason: "teste" });
  await new Promise((r) => setTimeout(r, 3100));
  assert.equal((await user.post("/api/radio/chat", { text: "outra" })).status, 403, "bloqueado não escreve");
  await admin.del(`/api/radio/admin/bans/${me.id}`);

  await admin.put("/api/radio/admin/settings", { access: "selected" });
  assert.equal((await user.get("/api/radio")).data.available, false, "acesso só para escolhidos");
  await admin.post(`/api/radio/admin/access/${me.id}`);
  assert.equal((await user.get("/api/radio")).data.available, true);

  // programação (cria e confere a agenda)
  const prog = await admin.post("/api/radio/admin/programs", { name: "Tarde", days: [0, 1, 2, 3, 4, 5, 6], startTime: "14:00", endTime: "16:00",
    trackIds: [song.id], active: true });
  assert.equal(prog.status, 200);
  assert.match(prog.data.program.scheduleLabel, /Todos os dias/);
  const progs = await admin.get("/api/radio/admin/programs");
  assert.ok(progs.data.agenda.length >= 6);

  assert.equal((await admin.post("/api/radio/admin/auto/end", { sessionId: st.sessionId })).status, 200);
  assert.equal((await user.get("/api/radio")).data.stations.length, 0);
});

// ------------------------------------------------------------------ persistência
test("os dados continuam após reiniciar o servidor", async () => {
  const cookie = user.cookie;
  await srv.stop();
  srv = await startServer(mocks.port, srv.dataDir);
  const again = client(srv.base);
  again.cookie = cookie;
  const me = await again.get("/api/me");
  assert.equal(me.status, 200, "a sessão continua válida");
  assert.equal((await again.get("/api/songs")).data.length, 2);
  assert.equal((await again.get("/api/plays")).data.length, 1);
});
